﻿Module Module1
    Public ChainID As Integer
    Public Geberation As Integer

    Public DeskNum As String
    Public Session As String

    Public EarnedMoney As Integer

    Public ExpCondtion As Integer
    Public INDIVIDUAL As Integer = 1
    Public OBLIQUE As Integer = 2
    Public VERTICAL As Integer = 3

    Public Generation As Integer

    Public InitialL As Integer
    Public InitialW As Integer
    Public InitialT As Integer

    Public SpeedMode As Integer

    Public ActionMode As Integer ' HUNTING = 1; KNAPPING = 2;
    Public HUNTING As Integer = 1
    Public KNAPPING As Integer = 2
    Public F1Activater As Integer = 0

    Public Today As Integer = 1

    Public Gender As Integer
    Public NOANSWER_G As Integer = 1
    Public FEMALE_G As Integer = 2
    Public MALE_G As Integer = 3
    Public NOTSURE_G As Integer = 4
    Public OTHER_G As Integer = 5

    Public Age As Integer

    'below: old items no longer functioning

    Public Season1Score As Integer
    Public Season2Score As Integer
    Public Season3Score As Integer


    Public IDinput As String
    Public IfInputInitialSoc As Integer
    Public IfInitialBimodalInput As Integer

    Public InitialSetting As Integer = 0
    Public StaringMode As Integer = 0

    Public QuadraticLandscape As Integer = 0


End Module
